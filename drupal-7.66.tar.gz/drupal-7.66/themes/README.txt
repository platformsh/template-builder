
This directory is reserved for core theme files. Custom or contributed themes
should be placed in their own subdirectory of the sites/all/themes directory.
For multisite installations, they can also be placed in a subdirectory under
/sites/{sitename}/themes/, where {sitename} is the name of your site (e.g.,
www.example.com). This will allow you to more easily update Drupal core files.

For more details, see: http://drupal.org/node/176043

